
// alertsPage.js
import { expect } from '@playwright/test';

export class AlertsPage {
  constructor(page) {
    this.page = page;
    this.handleConfirmalert=this.page.getByText('Alert with OK & Cancel')
    this.okBtn=this.page.locator('#OKTab button')
    this.demo=this.page.locator('#demo')
    this.cancelTab=this.page.locator('#CancelTab button')
    this.getAlert=this.page.getByText('Alert with Textbox')
    this.textBox=this.page.locator('#Textbox button')
    this.demo1=this.page.locator('#demo1')
  }
   async navigate() {
    await this.page.goto('https://demo.automationtesting.in/Alerts.html');

  }

  async handleSimpleAlert() {
    this.page.once('dialog', async (dialog) => {
      expect(dialog.message()).toBe('I am an alert box!');
      await dialog.accept();
    });

    await this.okBtn.click();
  }

  async handleConfirmAlertAccept() {
    await this.handleConfirmalert.click();

    this.page.once('dialog', async (dialog) => {
      expect(dialog.message()).toBe('Press a Button !');
      await dialog.accept();
    });

    await this.cancelTab.click();
    await expect(this.demo).toHaveText('You pressed Ok');
  }

  async handleConfirmAlertDismiss() {
    this.page.once('dialog', async (dialog) => {
      await dialog.dismiss();
    });

    await this.cancelTab.click();
    await expect(this.demo).toHaveText('You Pressed Cancel');
  }

  async handlePromptAlert() {
    await this.getAlert.click();

    this.page.once('dialog', async (dialog) => {
      await dialog.accept('Raju');
    });

    await this.textBox.click();
    await expect(this.demo1).toHaveText('Hello Raju How are you today');
  }
}
