import{expect} from '@playwright/test'
export class WindowsPage {

    constructor(page) {
        this.page = page;
        this.clickOntabbed=this.page.locator('a[href="#Tabbed"]');
        this.tabbedBtn=this.page.locator('#Tabbed button')
    }
    async navigate() {

       await this.page.goto('https://demo.automationtesting.in/Windows.html');
     }

    async openNewTabbedWindow() {
        await this.clickOntabbed.click();
        // Wait for new tab (popup)
        const newTabPromise = this.page.waitForEvent('popup');
        await this.tabbedBtn.click()
        const newTab = await newTabPromise;
        await newTab.waitForLoadState();
        await expect(newTab).toHaveURL(/selenium.dev/);
        // Return the new tab in case we need it
        return newTab;
    }

}

