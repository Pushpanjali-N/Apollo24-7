import{test,expect} from "@playwright/test"
// import {jsonData} from '../data/loginData.json'

export class loginDetails{
    constructor(page){
        this.page=page
        this.loginOption=this.page.getByText('Login', { exact: true })

        this.clickOnPhoneNumber=this.page.getByRole('textbox', { name: 'Please enter mobile number' })
        this.continueBtn=this.page.getByRole('button', { name: 'Continue' })
        this.verifyBtn=this.page.getByRole('button', { name: /^Verify$/ });
        this.signInTitle =() => page.locator('text=Sign In');
        this.closeBtn = this.page.locator('button[aria-label="Close"]');
        this.otpInput=this.page
            .locator('input[aria-label^="OTP"], input[data-testid*="otp"], input[type="tel"], input[inputmode="numeric"]')
            .first();
        this.resendBtn=this.page
            .locator('div[class*="SignIn_resendActions"]')
            .locator('button[title="Request resend otp"]');
    }
    

    async clickLogin(){
        await this.loginOption.click()
        await this.page.waitForTimeout(2000)
    }
    async login(mobileNo){
        await this.clickOnPhoneNumber.fill(mobileNo)
        await this.continueBtn.click()
        await expect(this.otpInput).toBeVisible();
        await this.otpInput.click(); 
        try {
            await expect(this.verifyBtn).toBeEnabled();
        } catch {
            await expect(this.resendBtn).toBeVisible();
            await expect(this.resendBtn).toBeEnabled();
            await this.resendBtn.click();
            await this.otpInput.click()
            console.log('Resend clicked. Please type the NEW OTP manually…');

            await expect(this.verifyBtn).toBeEnabled({ timeout: 35_000 });
        }

       
        await this.verifyBtn.click();
   
    }
    
   
}
