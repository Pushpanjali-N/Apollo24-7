import { expect } from '@playwright/test';
export class invalidInputSearch{
    
    constructor(page){
        this.page=page
        this.searchTerm=this.page.getByPlaceholder('Search Doctors, Specialities, Conditions etc.')
        this.giveInvalidInput = this.page.getByPlaceholder('Search Doctors, Specialities')
        this.listOfDoctors=this.page.locator('ul[class^="Search_searchResults_"]')

    }
    async searchForInvalidInput(invalidInput) {
        await this.searchTerm.click()
        await this.giveInvalidInput.fill(String(invalidInput))
        await this.listOfDoctors.waitFor({ state: 'visible', timeout: 15000 });
        const doctors = await this.listOfDoctors.locator('li').allTextContents();
        console.log('List Of Doctors:', doctors.map(i => i.trim()));
        console.log('Total Number of Doctors:', doctors.length);
        }

    }




