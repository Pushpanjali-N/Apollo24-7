import  XLSX from 'xlsx'

export function readData(fileName, sheetName) 
{
      const excelFile = XLSX.readFile('C:\\Users\\pushpn\\Desktop\\Appolo247\\tests\\data\\invalidInputData.xlsx')
     const excelSheet = excelFile.Sheets[sheetName]
     

     const loginJsonData = XLSX.utils.sheet_to_json(excelSheet)

     return (loginJsonData)

}