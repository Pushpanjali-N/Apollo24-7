
import { test as base} from '@playwright/test';
import {mobileNumber} from '../data/loginData.json'
import { loginDetails } from '../pages/loginDetails';
export const data = base.extend({
  logindata: async ({ page }, use) => {
    const api = {
      page,   
      async gotoHome(){
        await page.goto('/')
      },
      async openFindDoctors() {     
        await page.getByRole('link', { name: 'Find Doctors' }).click();   
      },
      async Login(){
          let loging= new loginDetails(page)
         for( let i of mobileNumber){
          await loging.login(i.Number)
        }
      }
      
    };
    await use(api);
  },
});

