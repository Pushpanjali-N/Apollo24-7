
// for(var i = 0; i < 11; i++)
// {
//     console.log(i)
// }

// console.log(i)


// var add = (num1, num2)=> {
//     return(num1+num2)
// }

// let r=add(30,40)
// console.log(r)


// add(40,50)
// function add(num1,num2){
//     console.log(num1+num2)

// }
// n=10;
// const numbers=[10,20,30,40,50]
// forEach (let i:numbers){
//    console.log(2*i)
// }


// const numbers = [ 10, 21, 31, 40, 50, 60 ]
// // const result = numbers.filter((a) =>a % 2 == 0).map((a) => a * 2)
// console.log(result) 


// const numbers=[10,20,30,40,50,60]
// for(let i=0;i<numbers.length;i++){
//     result=numbers.map(i%2==0){
//         return a;
//     }
    //  const result=numbers.filter((a,b)=>b%2==0).map((a)=>a*2).reduce((a,b)=>a+b)
    //  console.log(result)
//........................................................................
// find the maximum sum of the subarray of size k
// const array=[1,-2,-3,4,1,3]
// let sum=0, maxsum=0, start=0
// const k=3
// for(let i=0;i<array.length; i++){
//     sum+=array[i]
//     if(i>=k-1){
//         maxsum=Math.max(maxsum,sum)
//         sum-=array[start]
//         start++
//     }
    
// }
// console.log(maxsum)



// ...............................................................................................
// find the average maximum sum of the subarray of size k
// const array=[1,12,-5,-6,50,3]
// let sum=0,start=0,maxsum=0,k=4;
// for(let i=1;i<array.length-1;i++){
//      sum+=array[i];
//      if(i==k){
//           maxsum=Math.max(maxsum,sum);
//           sum-=array[i];
//           start++
//      }
// }
// console.log(maxsum/k)

// .....................................................................
// find the length of max sub array without forbidden value
// const array=[1,2,-3,4,1,3,4,-3,5]
// let maxsum=0, start=0, forbidden=3
// for(let i=0;i<array.length;i++){
//      sum+=i;
//      if(array[i]==forbidden){
//           start=start+i+1;
//      }
//      maxsum=Math.max(maxsum,i-start+1)

// } 
// console.log(maxsum)
// ....................................................................
// find the maximum subbarray value array
// const array=[4,-5,6,5,2,1]
// let maxsum=-Infifity, start=0, sum=0
// for(let right=0;right<array.length;right++){
//    sum+=array[right];
//    if(sum<0){
//       sum=0
//      start=right+1;
//     }
//      maxsum=Math.max(maxsum,sum)
// }
// console.log(maxsum)
// ............................................................
// find longest subarray with k unique/ distinct characters
// const data = [ 1, 1, 1, 1, 3, 2]
// const k = 2
// let windowLeft = 0
// let maxLength = 0
// // let windowRight = 0
// // const frequencyMap = new Map() 

//  { 4: 1, 1:2, 2: 1}

// for(windowRight = 0; windowRight < data.length; windowRight++)
//     {
//      if(frequencyMap.has(data[windowRight]))
//         {
//         frequencyMap.set(data[windowRight] , 
// frequencyMap.get(data[windowRight]) + 1)     
//         }
//         else
//         {
//             frequencyMap.set(data[windowRight], 1)
//         }

//         while( frequencyMap.size > k )
//         {
//             // remove old element data
//             let count = frequencyMap.get(data[windowLeft]) - 1
//             // count = 1
//             if(count == 0)
//             {
//                 frequencyMap.delete(data[windowLeft])
//             }
//             else{
//                 frequencyMap.set(data[windowLeft], count)
//             }
//             windowLeft++
//         }

//         maxLength = Math.max(maxLength, windowRight - windowLeft + 1)

//     }
// console.log(maxLength)

// ....................................................................................
// maximum sum of distinct subarrays with length 

//     let windowLeft = 0
//     let sum=0;
//     let windowRight = 0
//     let maxSum=-Infinity;
//     const frequencyMap=new Map()
//     const k=3
//     const data=[2,-3,1,-4,5,6,1]
//     for(windowRight = 0; windowRight < data.length;  windowRight++)
//     {
         

//      if(frequencyMap.has(data[windowRight]))
//         {
//         frequencyMap.set(data[windowRight] , frequencyMap.get(data[windowRight]) + 1)     
//         }
//         else
//         {
//             frequencyMap.set(data[windowRight], 1)
//         }
       
//             sum += data[windowRight];
        


//         while( windowRight - windowLeft + 1 > k )
//         {
            
//             // remove old element data
//             let count = frequencyMap.get(data[windowLeft]) - 1
//                 sum-=data[windowLeft]
//             // count = 1
//             if(count == 0)
//             {
//                 frequencyMap.delete(data[windowLeft])
//             }
//             else{
//                 frequencyMap.set(data[windowLeft], count)
//             }
//             windowLeft++
//         }
        
//            if (windowRight - windowLeft + 1 === k && frequencyMap.size === k) {
//             maxSum = Math.max(maxSum, sum);
//         }



//     }
//     console.log( maxSum)

// ....................................data..............................data...data

// maximum sum of distinct subarrays with length 
// const data = [2, -3, 1, -4, 5, 6, 1];
// const k = 3;

// let windowLeft = 0;
// let sum = 0;
// let maxSum = -Infinity;

// for (let windowRight = 0; windowRight < data.length; windowRight++) {
//     sum += data[windowRight];

//     // Shrink window if size exceeds k
//     if (windowRight - windowLeft + 1 > k) {
//         sum -= data[windowLeft];
//         windowLeft++;
//     }

//     // Check if window size is exactly k
//     if (windowRight - windowLeft + 1 === k) {
//         maxSum = Math.max(maxSum, sum);
//     }
// }

// console.log(maxSum); // Output: 12 (subarray [5,6,1])

// ......................................................................
// find te length of the longest substring without repeating characters
// const s="abacabcbb"
// let start=0, set=new Set(), maxlen=0;
// for(let end=0;end<s.length;end++){
//     while(set.has(s[end])){
//         set.delete(s[start])
//         start++
//     }
//     set.add(s[end])
//     maxlen=Math.max(maxlen,end-start+1)
// }
// console.log(maxlen)
// ....................................................................................
// find the maximum number of vowels in a substring of size k
// const s = "abciiidef";
// const k = 3;

// let count = 0, left = 0, maxlen = 0;
// const vowels = new Set(['a','e','i','o','u']);

// for (let right = 0; right < s.length; right++) {
//     if (vowels.has(s[right])) {
//         count++;
//     }

//     // Maintain window size k
//     if (right - left + 1 > k) {
//         if (vowels.has(s[left])) {
//             count--;
//         }
//         left++;
//     }

//     maxlen = Math.max(maxlen, count);
// }

// console.log(maxlen); 
// ................................................................
// logest substing with at most k distinct characters
// const s="aa" 
// const k=2
// let left=0, maxlen=0
// const map=new Map()
// for(let right=0;right<s.length;right++){
//     if(map.has(s[right])){
//         map.set(s[right], map.get(s[right])+1)
//     }else{
//         map.set(s[right],1)
//     }
//     while(map.size>k){
//         map.set(s[left],map.get(s[left])-1)
//         if(map.get(s[left])===0){
//             map.delete(s[left])
            
//         }
//        left++
        
//     }
// maxlen=Math.max(maxlen, right-left+1)
// }
// console.log(maxlen)

// ..................................................................
// sort string 
// const usernames = ["alex", "maria", "john", "luca"];

// const sorted = usernames.sort((a, b) => {
//     return a[a.length - 1].localeCompare(b[b.length - 1]);
// });

// console.log(sorted); // ["maria", "luca", "john", "alex"]


// ........................................................................
// repeated words
// const sentence = "I love love coding coding very very much indeed indeed";
// const words = sentence.toLowerCase().split(" "); // split by space
// const result = [];

// for (let i = 1; i < words.length; i++) {
//     if (words[i] === words[i - 1] && !result.includes(words[i])) {
//         result.push(words[i]);
//     }
// }
// console.log(result)

// .........................................................................
// words replace
// const sentence = "I love coding very much indeed";
// const k = 3;


//     const words = sentence.split(" "); // Step 1: Split into words
//     for (let i = 0; i < words.length; i++) {
//         if ((i + 1) % k === 0) {       // Step 2: Check position
//             words[i] = words[i].length; // Step 3: Replace with length
//         }
//     }
//    console.log(words.join(" "));            // Step 4: Join back

// .........................................................................
// remove word


// "hiii oko helllo welcomeee"
// let s = "hiii helllo welcomeee iamin"
// let arr = s.split(" ")
// // ['hiIi', 'helllo', 'welcomeee', 'ok']
// const result = []


// // "hiii iamin helllo welcomeee"

// for(let i = 0; i < arr.length; i++)
// {
//     let track = false // all are different

//     let data = arr[i].toLowerCase()// hiIi ==> hiii
   
//     // data = "oko"
//     for(let j = 0; j < data.length - 2; j++)
//     {
//         // j = 0 ==> oko
       
//         if((data[j] == data[j + 1] && data[j] == data[j + 2]) )
//         { 
//             track = true // all are same
//             break
//         }
        
//     }

//     if(track == false)
//     {
//         result.push(data)
//     }
// }

// console.log(result)

// //...........................................................

// function minWindow(s, t) {
//     if (t.length > s.length) return "";

//     const need = new Map();
//     for (let char of t) {
//         need.set(char, (need.get(char) || 0) + 1);
//     }

//     let have = 0, needCount = need.size;
//     const window = new Map();
//     let res = [-1, -1], resLen = Infinity;
//     let left = 0;

//     for (let right = 0; right < s.length; right++) {
//         let c = s[right];
//         window.set(c, (window.get(c) || 0) + 1);

//         if (need.has(c) && window.get(c) === need.get(c)) {
//             have++;
//         }

//         while (have === needCount) {
//             // Update result
//             if ((right - left + 1) < resLen) {
//                 res = [left, right];
//                 resLen = right - left + 1;
//             }

//             // Shrink from left
//             let leftChar = s[left];
//             window.set(leftChar, window.get(leftChar) - 1);
//             if (need.has(leftChar) && window.get(leftChar) < need.get(leftChar)) {
//                 have--;
//             }
//             left++;
//         }
//     }

//     return resLen === Infinity ? "" : s.slice(res[0], res[1] + 1);
// }

// // Example usage:
// console.log(minWindow("ADOBECODEBANC", "ABC")); // Output: "BANC"
// console.log(minWindow("a", "a"));               // Output: "a"
// console.log(minWindow("a", "aa"));              // Output: ""

// console.log("raju is going home".match(/\d{10}/))

// let s="pushpa@gmail.com"
// if(!(/[a-z]\d\./)){
//     console.log("email id is not valid")
// }
// if(!(/[@]/.test(s))){
//     console.log("email id is not valid")
// }
// if(!(/gmail\.com/)){
//     console.log("email id is not valid")
// }
// else {
//     console.log("valid")
// }


// let s="pushpanjali.12@gmail.com"


// if(!(/[^a-z0-9.]+$/.test(s))){
//     console.log("email id is not valid")
// }
// else if(!(s.length < 6 || s.length > 30))
// { console.log("email id is not valid")

// }
// else if(!(/[@]/.test(s))){
//     console.log("email id is not valid")
// }
// else if (!(/gmail\.com/.test(s))){
//     console.log("email id is not valid")
// }
// else{
// console.log("valid")
// }

//You must validate phone numbers using Regular Expressions (Regex).

// const s=["1234567890",
// "(123) 456-7890" ,
// "123-456-7890" ,
// "91 (123) 456-7890" ]

// const pattern=[/^\d{10}$/,
// /^\(\d{3}\) \d{3}-\d{4}$/,
// /^\d{3}-\d{3}-\d{4}$/,
// /^91 \(\d{3}\) \d{3}-\d{4}$/]
// let valid_count=0
// let invalid_count=0
// for(let i =0;i<s.length;i++){
//     if(pattern.some(p => p.test(s[i])))
//   {
//     valid_count++
//   }

// else{
//     invalid_count++
// }
// }

// console.log(valid_count)
// console.log(invalid_count)
//...................................................................
//Filename Guardian: Regex-Powered File Check

// const s="123report.csv"
// if(!/\.(txt|csv)$/.test(s)){
//     console.log("Invalid file extension")
// }
// if(!/^[a-z][a-z0-9_-]*$/.test(s)){
//     console.log("Invalid characters in filename")
// }
// else{
//     console.log("valid file extension")
// }


//===================================================================================

// //====================================================================================
//23RD

//PRACTICE QUESTIONS

// palindrome using for 
// const array = [3, 5, 7, 5, 3];
// let sum = 0;

// let left = 0;
// let right = array.length - 1;

// [1.]
// while (left < right) {
//     if (array[left] == array[right]) {
//         sum += array[left]+array[right];   // add the matching value
//     } else {
//         sum = 0;  
//         break            // reset if not palindrome
//     }
//     left++;
//     right--;
// }
// if (left === right) {
//     sum += array[left];
// }
// console.log(sum);
//=================================================================================
// [2.]
// const paragraph = "The cat bat sat on the big red bat."; 
// const regex = /\b[^aeiou\s?][aeiou\s?][^aeiou\s?]\b/ig;
// const matches = paragraph.match(regex);
// const count = matches ? matches.length : 0;
// console.log(count); // Output: 5
//===================================================================================
// [3.]
// const array=[5, 5, 5, 5]
// let set=new Set()
// let left=0

// while(left<array.length-1){
//     set.add(array[left])
//     left++
// }
// const count=set.size
// console.log(count)
//=====================================================================================
// [4.]

// const s="Hi John Doe"
// words=s.split(" ")
// const result=[]
// words.forEach((value)=>{
//     if(value.length%2==0){
//         result.push(value.split("").reverse().join(""))

//     }else{
//         result.push(value)
//     }
// });

// console.log(result.join(" "))
//===================================================================================
// [5.]

//  Match Dates in DD/MM/YYYY or DD-MM-YYYY Format

// Question:
// Write a regex that finds all valid dates in a text where the date is:

//  Day: 01 to 31
//  Month: 01 to 12
//  Year: 1900–2099
//  Separator can be `/` or `-`

// Example Input:

// ```
// The events are on 05/11/2024, 31-12-2023, and 45/10/2021.
// ```

// Expected Matches:

// ```
// 05/11/2024
// 31-12-2023
// ```

// (45/10/2021 should NOT match because 45 is not a valid day.)

// const text = "31/12/2024, 31-12-2023, 41/10/2021.";

// const regex = /\b(0?[1-9]|[12]\d|3[01])[-\/](0?[1-9]|1[0-2])[-\/](19|20)\d{2}\b/g;

// const matches = text.match(regex);

// console.log(matches); // [ '05/11/2024', '31-12-2023' ]
//===========================================================================================
// [7.]

// const s="Wow level noon dad cat pop Apple"
// const regex=/\b([a-zA-Z])[a-zA-Z]*\1\b/gi
// const matches = s.match(regex);

// console.log(matches);
//============================================================================================
// [6.]

// const text = "Loving the #JavaScript_2025 course! #fun #!wow #a";

// // Regex Explanation:
// // # → match hashtag start
// // (?=\w*[a-zA-Z]) → positive lookahead: ensures at least one letter
// // \w{2,} → letters/digits/underscore, minimum 2 characters
// const regex = /#(?=\w*[a-zA-Z])\w{2,}/g;

// const matches = text.match(regex).map(tag => tag.slice(1)); // remove '#'

// console.log(matches); 

// ======================================================================
//24-11-25

// class Student
// {
//     static totalStudent = 0

//     constructor()
//     {
//         Student.totalStudent++
//     }

//     static getTotalStudent()
//     {
//         return Student.totalStudent
//     }

// }

// const info = [ 5, 4, 1, 5, 5, 8, 10 ]

// let inputCount = info[0]
// // inputCount = 5

// for(let i = 1; i <= inputCount; i++)
// {
//     // i = 1 ==> 2
//     // i = 2 ==> 4
//     // i = 3 ==> 1
//     let noOfStudentJoiningTheCourseToday = info[i] // info[1]
//     // noOfStudentJoiningTheCourseToday = 2
//     for(let j = 0; j < noOfStudentJoiningTheCourseToday; j++)
//     {
//         // j = 0 ==> 1st student
//         // j = 1 ==> 2nd student
       
//         new Student()
//     }
    

// }

// console.log(Student.getTotalStudent())

// ====================================================================
//PRACTICE QUESTIONS
// 2. Counting Instances
// Tracking Cars in a Parking Lot
// You are building an app to track how many cars have been parked.
// • Implement a class Car with a static property count.
// • Each time a new Car object is created, increment count.
// • Implement Car.getCount() that returns the total cars parked.
// Input Format:
// • First line → integer (number of commands)
// • Next lines → each command has number of cars to park.
// Sample Input:
// 3
// 1
// 4
// 2
// Sample Output:
// 1
// 5
// 7

// class car{
//     static carCount=0
//     constructor(){
//         car.carCount++
//     }
//     static getCount(){
//         return car.carCount
//     }
// }
// const array=[3,1,4,2]
// let n=array[0]
// for(let i=1;i<=n;i++){
//     let numberOfCars=array[i]
//     for(let j=0;j<numberOfCars;j++){
//         new car()
       
//     }
//      console.log(car.getCount())
// }
// ==================================================================
// 5. Static Members: Orders in Restaurant
// Track the number of food orders placed in a restaurant.
// • Implement a class Order with a static property count initialized to 0.
// • Each new Order object increases count.
// • A static method getCount() should return the total orders so far.
// Input Format
// • First line → integer (number of order batches)
// • Next lines → number of orders in each batch
// Sample Input
// 2
// 3
// 4
// Sample Output
// 3
// 7

// class Restaurant{
//     static TotalCount=0
//     constructor(){
//         Restaurant.TotalCount++
//     }
//     static getCount(){
//         return Restaurant.TotalCount
//     }
// }
// const restaurant=[2,3,4]
// let n=restaurant[0]
// for(let i=1;i<=n;i++){
//     let numberOfRestaurant=restaurant[i]
//     for(let j=0;j<numberOfRestaurant;j++){
//         new Restaurant()

//     }
//     console.log(Restaurant.getCount())
// }

// =======================================================================
// 8. Static Members: Ticket Counter
// Track how many tickets have been sold for a movie.
// • Create a class Ticket with static property count.
// • Each new ticket increments count.
// • Implement getCount() to return current total.
// Input Format
// • First line → integer (number of ticket batches)
// • Next lines → number of tickets sold in that batch
// Sample Input
// 3
// 2
// 1
// 4
// Sample Output
// 2
// 3
// 7

// class ticket{
//     static ticketCounter=0
//     constructor(){
//         ticket.ticketCounter++
//     }
//     static getCount(){
//         return ticket.ticketCounter
//     }
// }
// const tickets=[3,2,1,4]
// let n=tickets[0]
// for(let i=1;i<=n;i++){
//     let numberOftickets=tickets[i]
//     for(let j=0;j<numberOftickets;j++){
//         new ticket()

//     }
//     console.log(ticket.getCount())
// }
//===================================================================================
//ENCAPSULATION 
// class BankAccount
// {
//     #accountNumber
//     #accountBalance //private variable

//     constructor(accountNumber, accountBalance)
//     {
//         this.accountNumber = accountNumber
//         this.#accountBalance = accountBalance
//     }

//     setAccountBalance(recievedBalance)
//     {
//         if(recievedBalance > 0)
//         {
//             this.#accountBalance = recievedBalance
//         }
//     }

//     getAccountBalance()
//     {
//         return this.#accountBalance
//     }
// }

// const account = new BankAccount(10000001, 2000)
// account.setAccountBalance(-4000)

// console.log(account.getAccountBalance())
// =============================================================
// 3. Encapsulation in Action
// Library Management: Tracking Books
// Implement a class Library demonstrating encapsulation.
// • Maintain a private property books (number of books, starts at 0).
// • Provide methods:
// o addBook(amount: number) → adds books if amount > 0
// o borrowBook(amount: number) → reduces books if enough are available
// o getBooks() → returns total books available
// Input Format:
// • First line → integer (number of operations)
// • Next lines → operation (add, borrow, books)
// Sample Input:
// 5
// add 10
// borrow 3
// books
// borrow 9
// books
// Sample Output:
// 7
// 7
// class libraryManagement{
//     #amount=0
   
//     addBook(value){
//         if(value>0){
//             this.#amount+=value
//         }
//     }
//     borrowBook(value){
//         if(value>0&& value<=this.#amount){
//             this.#amount-=value
//         }
//     }
//     getBooks(){
//         return this.#amount
//     }

// }

//===============================================================================


// const input=[5, "add 10", "borrow 3", "books", "borrow 9", "books"]
// let n=input[0]
//  const lm=new libraryManagement()
// for(let i=1;i<=n;i++){
   
//    const [command,value]=input[i].split(" ")
// //    const command = parts[0];
// //    const value = parts[1];
//    if(command=="add"){
//       lm.addBook(parseInt(value))
//    }
//    else if(command=="borrow"){
//         lm.borrowBook(parseInt(value))
//    }
//    else if(command=="books"){
//     console.log(lm.getBooks())
//    }
// }



//...............................................................................
//...............................................................................
//24TH -2025
//JAVA OOPS

// function Student(roll_no, username,age){
//     this.roll_no=roll_no
//     this.username=username
//     this.age=age

// }
// Student.prototype.displayDetails=function(){
//     console.log(this.roll_no)
//     console.log(this.username)
//     console.log(this.age)

// }
// const studentdata1=new Student(1,"raju",13)
// const studentdata2=new Student(2,"ramu",14)
// const studentdata3=new Student(3,"raj",15)

// console.log(studentdata1)
// console.log(studentdata2)
// console.log(studentdata3)


//
// class Student{

//     static count=0
//     constructor(roll_no, username,age){
//         this.roll_no=roll_no
//         this.username=username
//         this.age=age

//         Student.count++

//     }

// }



// const studentdata1=new Student(1,"raju",13)
// const studentdata2=new Student(2,"ramu",14)
// const studentdata3=new Student(3,"raj",15)

// // console.log(studentdata1)
// // console.log(studentdata2)
// // console.log(studentdata3)
// console.log(Student.count)


//========================================================================
// practice question on typescript
// 2. Counting Instances  
// Tracking Cars in a Parking Lot 
// You are building an app to track how many cars have been parked. 
// • Implement a class Car with a static property count. 
// • Each time a new Car object is created, increment count. 
// • Implement Car.getCount() that returns the total cars parked. 
// Input Format: 
// • First line → integer (number of commands) 
// • Next lines → each command has number of cars to park. 
// Sample Input: 
// 3 
// 1 
// 4 
// 2 
// Sample Output: 
// 1 
// 5 
// 7


// class car
// {
//     static count = 0

//     constructor()
//     {
//         car.count++
//     }

//     static get_count()
//     {
//         return car.count
//     }

// }
// const array=[3 ,1, 4, 2]
// let info=array[0]//number of element in an array

// for(let i = 1; i <= info; i++)
// {
   
//     let number = array[i] // info[1]
    
//     for(let j = 0; j < number; j++)
//     {
//         new car()
//     }
//     console.log(car.get_count())
// }
//===============================================================================
// class Student
// {
//     static totalStudent:number = 0

//     constructor()
//     {
//         Student.totalStudent++
//     }

//     static getTotalStudent()
//     {
//         return Student.totalStudent
//     }

// }

// const info = [3 ,1, 4, 2]

// let inputCount = info[0]
// // inputCount = 5

// for(let i = 1; i <= inputCount; i++)
// {
//     // i = 1 ==> 2
//     // i = 2 ==> 4
//     // i = 3 ==> 1
//     let noOfStudentJoiningTheCourseToday = info[i] // info[1]
//     // noOfStudentJoiningTheCourseToday = 2
//     for(let j = 0; j < noOfStudentJoiningTheCourseToday; j++)
//     {
//         // j = 0 ==> 1st student
//         // j = 1 ==> 2nd student
       
//         new Student()
//     }
//     console.log(Student.getTotalStudent())
//==============================================================================
// }
// class animal{
//     sound(){
//         console.log("animal makes sound")
//     }
// }
// class lion extends animal{
//     sound(){
//         console.log("lion makes sound")

//     }
// }
// class cat extends animal{
//     sound(){
//         console.log("cat makes sound")
//     }
// }

// const data=[3, "animal", "lion", "cat"]

// let n=data[0]
// for(let i=1;i<=n;i++){
//     let info=data[i]
//     if(info==="animal"){
//         const a=new animal()
//         a.sound()
//     }
//     else if(info==="lion"){
//         const l=new lion()
//         l.sound()
//     }
//     else{
//         const c=new cat()
//             c.sound()
        
//     }
// }


// class animal{
    
//     getType(){
//         return "Animal"
//     }
// }
// class lion extends animal{
//     getType(){
//         return "Lion"

//     }
// }


// const data=[3, "animal", "lion", "cat"]

// let n=data[0]
// for(let i=1;i<=n;i++){
//     let info=data[i]

//     if(info==="animal"){
//         const a=new animal()
//        console.log(a.getType())
//     }
//     else if(info==="lion"){
//         const l=new lion()
//         console.log(l.getType())
//     }

// }
//===================================================================================
// class car{
    
//     getType(){
//         return "car"
//     }
// }
// class bike extends car{
//     getType(){
//         return "bike"

//     }
// }


// const data=[2, "car","bike"]

// let n=data[0]
// for(let i=1;i<=n;i++){
//     let info=data[i]
//     if(info==="car"){
//         const c=new car()
//        console.log(c.getType())
//     }
//     else if(info==="bike"){
//         const b=new bike()
//         console.log(b.getType())
//     }

// }

//polymorphism==================================================

//[4.]

// class Devices{
//     operate(){
//         return "generic devices"
//     }

// }
// class light1 extends Devices{
//     operate(){
//         return "light on"
//     }
// }
// class fan1 extends Devices{
//     operate(){
//         return "fan spinning"
//     }
// }
// const data=[3,"light","fan","light"]
// let n=data[0]
// for(let i=0;i<n;i++){
//     let string=data[i]
//     let obj
    
//     if(string==="light"){
//         obj=new light1()

//     }
//     else if(string==="fan"){
//         obj=new fan1()
//     }
//     else{
        

//     obj = new Devices(); // fallback to avoid undefined
  

//     }
//     console.log(obj.operate())
// }


// class carParking{
//     static count=0
//     constructor(){
//         carParking.count++
//     }
//     static getCount(){
//         return carParking.count
//     }
// }
// const data=[3, 1,5,6]
// let n=data[0]
// for(let i=1;i<=n;i++){
//     let no=data[i]
//     for(let j=0;j<no;j++){
//         new carParking()
//     }
//     console.log(carParking.getCount())
// }


///practice question on js 
//[1]
// let n=5
// const data=[2, 4, 5, 8, 26]//output=11010
// const result=[]
// for(let i=0;i<n;i++){
//   if(data[i]%2==0){
//     result.push(1)
//   }
//   else{
//     result.push(0)
//   }
// }

// console.log(result.join(""))


//[2]
// const words="Please please help me me quickly Quickly"
// const data=words.toLowerCase().split(" ")
// const result=[]
// for(let i=0;i<data.length;i++){
//     // console.log(data[i])
//     if(data[i]==data[i+1] && !result.includes(data[i])){
//         result.push(data[i])
       
//     }
// }
// console.log(result.join(""))


// ============================================================================
//25TH PRACTICED QUESTIONS
// Password Protector: Regex-Powered Security Check
// You’re creating a system that validates a password before allowing user registration.
// Password Rules:
// 1. It must be at least 8 characters long → else print "Password too short".
// 2. It must contain at least one uppercase letter → else print "Must contain an
// uppercase letter".
// 3. It must contain at least one digit → else print "Must contain a digit".
// 4. It must contain at least one special character (!@#$%^&*) → else print "Must
// contain a special character".
// 5. It must not contain spaces → else print "Spaces not allowed".
// If all rules pass → print "Valid password"
// Input Format
// A single string containing the password.
// Sample Input
// Weakpass
// Sample Output
// Must contain a digit

// const password="Push@#"
// if(!password.length>0 && !password.length<=8){
//     console.log("password too short")
// }
// else if(!/[A-Z]/.test(password)){
//     console.log("Must contain an ippercase letter")
// }
// else if(!/[0-9]/.test(password)){
//     console.log("Must contain a digit")
// }
// else if(! /[!@#$%^&*]/.test(password)){
//     console.log("Must contain a special character")
// }
// else if(/\s/.test(password)){
//     console.log("spaces not allowed")
// }
// else{
//     console.log("valid password")
// }
// ==================================================================================

// 7.Filename Guardian: Regex-Powered File Check
// You are building a system that checks file names uploaded by users.
// Filename Rules:
// 1. It must end with .txt or .csv → else print "Invalid file extension".
// 2. It must contain only letters, numbers, underscores, or dashes before the extension
// → else print "Invalid characters in filename".
// 3. It must not exceed 20 characters (excluding extension) → else print "Filename too
// long".
// 4. It must not start with a digit → else print "Filename must not start with a digit".
// If all rules pass → print "Valid filename"
// Input Format
// A string containing a file name.
// Sample Input
// 123report.txt
// Sample Output
// Filename must not start with a digit


// const filename = "reporthghfghgjgjg1212.txt";

// // Rule 1: Must end with .txt or .csv
// if (!/\.(txt|csv)$/.test(filename)) {
//     console.log("Invalid file extension");
// } else {
//     // Extract the filename **excluding the extension**
//     const dotIndex = filename.lastIndexOf(".");
//     const name = filename.substring(0, dotIndex);

//     // Rule 2: Only letters, numbers, underscores, dashes
//     if (!/^[A-Za-z0-9_-]+$/.test(name)) {
//         console.log("Invalid characters in filename");
//     }
//     // Rule 3: Must not exceed 20 characters (excluding extension)
//     else if (name.length > 20) {
//         console.log("Filename too long");
//     }
//     // Rule 4: Must not start with a digit
//     else if (/^[0-9]/.test(name)) {
//         console.log("Filename must not start with a digit");
//     }
//     // All rules passed
//     else {
//         console.log("Valid filename");
//     }
// }
//====================================================================================
// 8. Product Code Inspector: Regex-Powered Inventory Check
// You’re validating product codes for a warehouse system.
// Product Code Rules:
// 1. Must start with two uppercase letters (category code).
// 2. Followed by 4 digits (product ID).
// 3. Optionally, may end with a dash and 2 uppercase letters (region code).
// 4. Anything else → "Invalid product code".
// If all rules pass → "Valid product code"
// Input Format
// A string representing the product code.
// Sample Input
// AB1234-NY
// Sample Output
// Valid product code

// const s="AB1234-NY"


//====================================================================================

// 26th
//sorting algorithm==>buuble sorting
// let words=["apple","banana","grape","orange", "kiwi"]
// // let ouput=["banana", "apple", "grape","organge","kiwi"]

// for(let i=0;i<words.length;i++){
//     for(let j=0;j<words.length-1;j++){
//         let currentword= words[j].substring(words[j].length - 1)
//         let nextword = words[j + 1].substring(words[j + 1].length - 1) 

//         if(currentword>nextword){
//             [words[j+1],words[j]]=[words[j],words[j+1]]
//         }
//     }

// }
// console.log(words)

//=============================================================================================
//error handling 

// risky code ==>  the code that can give the error / work in a wrong manner

// let a = 10
// let b = 0

// if(b == 0)
// {
//     console.log("Denominator cannot be zero!")
//     console.log("Hello")
// }
// else
// {
//     console.log(a / b)
// }

// ==============================================

// let a = 10
// let b = 5
// console.log(a / b)


// throw ==> throw keyword is used to throw a message, but it ternimates the program from the next line onwards

// any message we want to throw, give that message to the Error class
// constructor

// class Error
// {
//     message
//     name
//     constructor(errorMessage)
//     {
//         this.message = errorMessage
//         // this.message = "Insufficient balance"
//         // this.name = "----"
//     }
// }


// withdraw(amount)
// {
//     if(amount > totalBalance)
//     {
//         throw  new Error("Insufficient balance")
//         console.log("Insufficient balance")
        
//     }
// }


// erro to handle ==> catch()
// any code can throw the erro, if that code is a part of try block



// class WrongDenominator extends Error
// {
   
//     constructor(message)
//     {
//         super(message)
//         this.name = "DivisionByZero"
//     }
// }

// let a = 10
// let b = 0

// try
// {
//     if(b == 0)
//     {
//         throw new WrongDenominator("Denominator cannot be zero!")
//         // console.log("Denominator cannot be zero!")
//     }
// }

// // e = new WrongDenominator("Denominator cannot be zero!")
// catch(e)
// {
//     console.log(e.message)
//     console.log(e.name)

//     console.log(e)
// }

// // name == message


//==================================================================================
//practice string question
// 1) Palindrome Array Checker (Two Pointer)-----------------------------------------------------------
// You are given an array of numbers
//  You must:
//  Step 1: Check if the array is a palindrome
//  A palindrome means:
//  First element = Last element
//  Second element = Second last
//  And so on…
//  Use the two-pointer method:
//  left pointer → index 0
//  right pointer → last index
//  Do NOT reverse the array.
//  Return:
//  CASE 1: If palindrome → return sum of elements
//  CASE 2: If NOT palindrome → return index of first mismatch (0-based)
//  Examples:
//  Input: [3, 5, 7, 5, 3]
//  Output: 23
//  Input: [2, 4, 6, 4, 9]
//  Output: 0
//  Input: [4, 2, 6, 3, 4]
// Output: 1
//  Input: [8, 9, 9, 8]
//  Output: 34
//  Input: [10]
//  Output: 10

//===========================================================================
// 2) Count CVC Words in a Paragraph (Regex)
// CVC = Consonant – Vowel – Consonant
//  Rules:
//  • Word must be exactly 3 letters
//  • 1st letter = consonant
//  • 2nd letter = vowel
//  • 3rd letter = consonant
//  • Case-insensitive
//  • No numbers or symbols
//  Vowels: a, e, i, o, u
//  Task:
//  Read a paragraph and count words matching CVC using regex.
//  Example:
//  Input: "The cat sat on the big red bat."
//  Output: 5



//=====================================================================================

// 3) Count Unique Elements in Sorted Array (Two-Pointer)-----------------------------------------------------------
// Given a sorted array, remove duplicates and keep one copy of each.
//  Return ONLY the count of unique elements.
//  Two-pointer approach:
// i → track unique
//  j → scanner
//  When arr[j] != arr[i], increment i.
//  Examples:
//  Input: [1, 1, 2, 2, 2, 3, 4, 4]
//  Output: 4
//  Input: [5, 5, 5, 5]
//  Output: 1
//  Input: [1, 2, 3, 4]
//  Output: 4
//  Input: []
//  Output: 0


// const array=[1, 1, 2, 2, 2, 3, 4, 4]
// const set=new Set()
// for(let i=0;i<array.length;i++){
//     set.add(array[i])
    
// }
// console.log(set.size)

//============================================================================

// 4) Reverse Only Words With Even Length (NO loops, NO regex)
// Given a sentence:
//  If word length is even → reverse it
//  If odd → keep same
//  Spaces must remain exactly same.
//  Allowed:
//  .trim(), .split(" "), .map(), .join(), .length
//  Examples:
//  "Hello world" → "Hello world"
//  "Hi John Doe" → "iH nhoJ Doe"
//  "Time to code" → "emiT ot edoc"


//  const s="Hi John Doe"
//  words=s.split(" ")
// const result=[]
// words.forEach((value)=>{
//     if(value.length%2==0){
//         result.push(value.split("").reverse().join(""))

//     }else{
//         result.push(value)
//     }
// });

// console.log(result.join(" "))
//...........................................................................................
// const s="Hi John Doe"
// // const word=s.split(" ")
// // const words=s.split(" ")
// // console.log(words)
// const words=s.split(" ")
// const result=[]
// // if(words.map(w=>w.length%2==0)){
// words.map(w=>{
//     if(w.length%2==0){
//         result.push(w.split("").reverse().join(""))
//     }else{
//         result.push(w)
//     }
// });
    
// console.log(result.join(" "))

//=============================================================================
// 5) Count Words With Alternating Characters (a → b → a → b)
// -----------------------------------------------------------
// A valid alternating word:
//  • Adjacent characters must differ
//  • Any length ≥ 2
//  Example:
//  Valid: aba, xyx, pap, 1212
//  Invalid: aa, abba, hello
//  Input: "aba xyx hello pap"
//  Output: 3

// const s="aba xyx hello pap"
// var word=s.split(" ")//["aba","xyx","hello","pap"]
// // console.log(word)
// const result=[]

// // const words=[]
// let count=0
// for(let i=0;i<word.length;i++){
//     let letter=word[i].split("")//["a","b","a"]//["h","E","l","l","o"]
//     let h=true
//     for(let j=0;j<letter.length;j++){
//         if(letter[j]==letter[j+1]){
//            h=false
//            break;
//         }
        
//     }
//     if(h){
    
//         result.push(word[i])
//     }
    

    
// }
// console.log(result)

//====================================================================================
//) Reverse Only the Vowels in a String-----------------------------------------------------------
// Reverse vowels but keep consonants fixed.
//  Example:
//  Input: leetcode
//  Output: leotcede

// const s="leetcode"
// const word=s.split("")//
// // console.log(word)
// const result=[]
// const vowels=new Set(['a','e','i','o','u','A','E','I','O','U'])
// let left=0
// // console.log(left)
// let right=s.length-1
// // console.log(right)
// while(left<right){
//     if(vowels.has(word[left]) && vowels.has(word[right])){
//         [word[left], word[right]] = [word[right], word[left]];
//         right--
//         left++
//         // console.log(word)
//     }else if(vowels.has(word[left]) && !vowels.has(word[right])){
//         right--
        
//     }
//     else{
//         left++
//     }

// }
// console.log(word.join(""))
    

//========================================================================
// -----------------------------------------------------------
// 7) Count Pairs With Given Sum (Two-Pointer)-----------------------------------------------------------
// Input:
//  n
//  n sorted numbers
//  target sum
//  Example:
//  Input:
//  6
//  1 2 3 4 5 6
//  7
//  Output: 3

// let n=9
// const array=[1,2,3,4,5,6,8,9,10]
// //{1,6} {2,4},{3,4}// 
// //[1+6=7],[2+4=7],[3+4=7]
// // length=3
// let target_sum=12
// let count=0
// let left=0
// let right=n-1
// while(left<right){
//     if((array[left]+array[right])==target_sum){
//         count++
//         right--
//         left++
//     }
//     else if(array[left]+array[right]<target_sum){
//         left++
//     }
    
//     else{
//         right--
//     }

// }
// // if(left<n){
// //     left++
// //     right=n-1

// // }
// console.log(count)

//==============================================================================

// 8) Convert CamelCase to snake_case
// Example:
//  Input: convertThisString
//  Output: convert_this_string

// const s="convertThisString"
// const result=[]
// const word=s.split("")
// // console.log(word)
// for(let i=0;i<word.length;i++){
    
//     if(word[i]==word[i].toLowerCase()){
//         result.push(word[i])
//     }else{
        // // let h='_'
//         result.push('_')
//         result.push(word[i].toLowerCase())
//     }
// }
// console.log(result.join(""))

//=======================================================================

// 9) First Non-Repeating Character in a String
// Return first character appearing only once.
//  If none → return -1
//  Example:
//  Input: aabbcdd
//  Output: c

// const s="abbadadf"
// const map=new Map()
// let left=0
// // if()
// for(let right=0;right<s.length;right++){
//     if(map.has(s[right])){
//         map.set(s[right], map.get(s[right])+1)
//     }
//     else{
//         map.set(s[right],1)
//     }
// }
// for(let [char,freq] of map){
//     if(freq==1){
//         console.log(char)
//     }
// }
//====================================================================
// 10) Count Words Starting and Ending With Same Letter
// Case-insensitive
//  Example:
//  Input: "Anna went to Asia and met Arora"
//  Output: 3

// const s="Anna went to Asia and met Arora"
// const word=s.toLowerCase().split(" ")
// let count=0
// for(let i=0;i<word.length;i++){
//     w=word[i].split("")
   
//     // console.log(w)
    
//     let left=0
//     let right=w.length
//     // console.log(right)
//     // console.log(w[left])
//     // console.log(w[right-1])
//     if(w[left]==w[right-1]){
//         count++
        
//     }
    
// }
// console.log(count)


//===========================================================================

// 11) Remove Consecutive Duplicate Characters
// Example:
//  Input: xxxyyyzzz
//  Output: xyz

// const s="xxxyyyzzz"
// const set=new Set()
// let result=[]
// let left=0,right=s.length-1
// while(left<right){
//     set.add(s[left])
//     left++

// }
// for(let char of set){
//     result.push(char)
// }
// console.log(result.join(""))


//===================================================================================

// 12) Check if Two Strings Are Anagrams
// -----------------------------------------------------------
// Ignore case and spaces.
//  Output: YES or NO
//  Example:
//  Listen
//  Silent
//  → YES
// Dormitory – Dirty Room
// const s1="Listen"
// const s2="Silent"
// const word1=s1.toLowerCase().replace(/\s/g, "").split("")
// const word2=s2.toLowerCase().replace(/\s/g, "").split("")
// const map=new Map()
// let left=0
// for(let right=0;right<word1.length;right++){
//     if(map.has(word1[right])){
//         map.set(word1[right], map.get(word1[right])+1)
//     }
//     else{
//         map.set(word1[right],1)
//     }
// }
// let h=false
// if(word1.length==word2.length){
//     for(j=0;j<word2.length;j++){
//         if(map.has(word2[j])){
//             h=true
//             break
//         }
//    }
// }

// if(h){
//     console.log("yes")
// }else{
//     console.log("no")
// }

//=========================================================

// 13) Rotate Array Right by K Positions
//  Input:
//  5
//  1 2 3 4 5
//  2
//  Output:
//  4 5 1 2 3

// const array=[1,2,3,4,5]
// n=array.length-1
// let k=2
// const result=[]
// for(let i=0;i<=k;i++){
//    result.push(array[i])
     
// }
// //5-2=3
// for(let j=n;j>k;j--){
//     result.unshift(array[j])
// }
// console.log(result)

//=========================================================================

// 14) Count Words That Contain Only Digits
// Example:
//  Input: "My id is 9876 and pin is 4321"
//  Output: 2

// const s="My id is 9876 and pin is 4321"
// const word=s.split(" ")
// console.log(word)
// let count=0
// for(let i=0;i<word.length;i++){
   
//     if(!word[i]==Number){
//         count++
//     }
// }
// console.log(count)


//==================================================================================

//  1. Username Validation

// Rules:

//  Must start with a letter
//  Can contain letters, digits, underscores
//  Length 5–12

// Sample Input:

// ```
// john_99
// ```

// Output:

// ```
// Valid

// const s="1ohn99"
// const regex=/^[A-Za-z][A-Za-z0-9_]{4,11}$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }

//==================================================================
// 2. Strong Word Rule

// Rules:

//  Only lowercase letters
//  Must contain at least one vowel
//  No digits, no symbols

// Sample Input:

// ```
// strength
// ```

// Output:

// ```
// Valid
// ```

// const s="stre1ngth"
// const regex=/^[a-z]+[aeiou][a-z]$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }

//==================================================================
//  3. Product Code

// Rules:

//  Starts with 3 uppercase letters
//  Followed by 4 digits
//  Ends with -X or -Y

// Sample Input:

// ```
// ABC1234-X
// ```

// Output:

// ```
// Valid

// const s="ABC1234X"
// const regex=/^[A-Z]{3}[0-9]{4}(-X|-Y)$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }

//==========================================================================
// 4. File Extension Matcher

// Rules:

//  Ends with .jpg, .png, or .gif
//  Letters/digits before extension

// Sample Input:

// ```
// summer2024.png
// ```

// Output:

// ```
// Valid

// const s="Summer2024.png"
// const regex=/^[A-Za-z0-9]+\.(jpg|png|gif)$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }
//====================================================================================

// 5. Student ID Format

// Rules:

//  Starts with STU-
//  Followed by 3 digits
//  Ends with 2 uppercase letters

// Sample Input:

// ```
// STU-492AB
// ```

// Output:

// ```
// Valid


// const s="STU-492AB"
// const regex=/^STU-[0-9]{3}[A-Z]{2}$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }
//===============================================================================
// 6. Match Decimal Numbers

// Rules:

//  Valid: 123, 123.45, .45, 0.89

// Sample Input:

// ```
// 123.45
// ```

// Output:

// ```
// Valid
// const s="0.45"
// const regex=/^([0-9]+)?\.[0-9]{2}$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }
//===============================================================================

// 7. Vehicle Registration Number

// Rules:

//  Two uppercase letters
//  Two digits
//  Two uppercase letters
//  Four digits

// Sample Input:

// ```
// AP05BZ3781
// ```

// Output:

// ```
// Valid
// const s="AP05BZ3781"
// const regex=/^[A-Z]{2}[0-9]{2}[A-Z]{2}[0-9]{4}$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }
//================================================================================

// 8. Password Format

// Rules:

//  Only letters + digits
//  Must not start with a digit
//  Length 6–10

// Sample Input:

// ```
// A1b2c3
// ```

// Output:

// ```
// Valid

// const s="A1b2c3"
// const regex=/^[A-Za-z][A-Za-z0-9]{5,9}$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }

//===============================================================

// 9.Match IP Address (Simple)

// Rules:

//  Four numbers, 1–3 digits each, separated by dots

// Sample Input:

// ```
// 192.168.0.1
// ```

// Output:

// ```
// Valid

// const s="192.168.0.1"
// const regex=/^[0-9]{1,3}(\.[0-9]{1,3}){3}$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }

//==================================================================
// 10. Coupon Code

// Rules:

//  2 uppercase letters - 3 digits - 3 letters (any case)

// Sample Input:

// ```
// AB-123-xyZ
// ```

// Output:

// ```
// Valid

// const s="AB-123-xyZ"
// const regex=/^[A-Z]{2}-[0-9]{3}-[A-Za-z]{3}$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }
//===========================================================================

//  11. Name Format

// Rules:

//  Only alphabets
//  Must start uppercase, rest lowercase

// Sample Input:

// ```
// Raju
// ```

// Output:

// ```
// Valid
// const s="Raju"
// const regex=/^[A-Z][a-z]+$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }

//==============================================================================
// 12. Time Format HH:MM

// Rules:

//  Hours 00–23
//  Minutes 00–59

// Sample Input:

// ```
// 09:59
// ```

// Output:

// ```
// Valid

// const s="23:45"
// const regex=/^[0-23]+:[0-59]+$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }
//====================================================================

//  13. Simple URL Format

// Rules:

//  Starts http:// or https://
//  Domain letters/digits
//  Ends with .com

// Sample Input:

// ```
// https://google.com
// ```

// Output:

// ```
// Valid
// const s="https://google.com"
// const regex=/^(https?):\/\/[A-Za-z0-9]+\.(com|in)$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }

//===============================================================================

// 14. PAN Card Format

// Rules:

//  5 uppercase letters
//  4 digits
//  1 uppercase letter

// Sample Input:

// ```
// ABCDE1234F
// ```

// Output:

// ```
// Valid
// const s="ABCDE1234F"
// const regex=/^[A-Z]{5}[0-9]{4}[A-Z]$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }

//============================================================================

//  15. Address Line Validator

// Rules:

//  Allowed: letters, digits, spaces, commas, dots

// Sample Input:

// ```
// 12, MG Road, Bangalore.
// ```

// Output:

// ```
// Valid
// ```

// const s="12, MG Road, Bangalore."
// const regex=/[A-Za-z0-9\s,\.]+/g
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }

//==========================================================================

// 16. Email Validation

// Rules:

//  Letters, digits, ., _, + allowed before @
//  Must contain @ and domain
//  Ends with 2–4 letter domain

// Sample Input:

// ```
// test123@gmail.com
// ```

// Output:

// ```
// Valid
// ```

// const s="test123@gmail.com"
// const regex=/^^[A-Za-z0-9._+]+@gmail\.com$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }


//=====================================================================
// 
// 6 groups of 2 hexadecimal digits
//  Separated by :

// Sample Input:

// ```
// 00:1A:2B:3C:4D:5E
// ```

// Output:

// ```
// Valid
// ```

// Regex:

// ```
// ^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$
// ```
// const s="00:1A:2B:3C:4D:5E"
// const regex=/^([0-9A-Fa-f]{2}:){6}$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }
//=============================================================================

//  20. Date DD/MM/YYYY

// Rules:

//  Day 01–31
//  Month 01–12
//  Year 1000–2999

// Sample Input:

// ```
// 31/12/2020
// ```

// Output:

// ```
// Valid

// const s="31/12/2020"
// const regex=/^[1-31]\/[1-12]\/[-29]$/
// if(s.match(regex)){
//     console.log("valid")
// }else{
//     console.log("invalid")
// }

// class Wallet
// {
//     #amount = 0 // 100

//     addMoney(x)
//     {
//         if(x > 0)
//         {
//             this.#amount = this.#amount + x
//         }
//     }

//     spendMoney(x)
//     {
//         if(x > 0 && x <= this.#amount)
//         {
//             this.#amount = this.#amount - x
//         }
//     }

//     getAmount()
//     {
//         return this.#amount
//     }
// }



// const data = [ 4, "add 80", "spend 40", "amount", "spend 100" ]

// let inputCount = data[0]

// const wallet =  new Wallet()

// for(let i = 1; i <= inputCount; i++)
// {
//     let info = data[i] // data[1]
//     // info = [ "add 100"]
//     const [ commandAndInput, value ] = info.split(" ")//array desturcture
 
//     if(commandAndInput == "add")
//     {
//         wallet.addMoney(parseInt(value))
//     }
//     else if(commandAndInput == "spend")
//     {
//         wallet.spendMoney(parseInt(value))
//     }
//     else if(commandAndInput == "amount")
//     {
//         console.log(wallet.getAmount())
//     }
// }



// //================================================================

// //polymorphism==================================================

// //[4.]

// class Devices{
//     operate(){
//         return "generic devices"
//     }

// }
// class light1 extends Devices{
//     operate(){
//         return "light on"
//     }
// }
// class fan1 extends Devices{
//     operate(){
//         return "fan spinning"
//     }
// }
// const data=[3,"light","fan","light"]
// let n=data[0]
// for(let i=0;i<n;i++){
//     let string=data[i]
//     let obj
    
//     if(string==="light"){
//         obj=new light1()

//     }
//     else if(string==="fan"){
//         obj=new fan1()
//     }
//     else{
        

//     obj = new Devices(); // fallback to avoid undefined
  

//     }
//     console.log(obj.operate())
// }

//===========================================================================
//trim array ends greater than threshold
// function countTrimmedArray(arr, k) {
//     let left = 0;
//     let right = arr.length - 1;

//     // Move left pointer until value <= k
//     while (left <= right && arr[left] > k) {
//         left++;
//     }

//     // Move right pointer until value <= k
//     while (left <= right && arr[right] > k) {
//         right--;
//     }

//     // Remaining elements countv 
 
//     return right - left + 1;
// }

// // INPUT
// // let arr = gets().split(' ').map(Number);
// // let k = parseInt(gets());

// // // OUTPUT
// k=10
// arr[10,12,5,6,7,15,20]
// console.log(countTrimmedArray(arr, k));
// //==============================================================================


// function countUniqueElements(arr) {
//     // Edge cases
//     if (!arr || arr.length === 0) return 0;
//     if (arr.length === 1) return 1;

//     // Two-pointers idea:
//     // left points to the last unique value we have seen
//     // right scans through the array
//     let uniqueCount = 1; // first element is always unique in a non-empty sorted array
//     let left = 0;

//     for (let right = 1; right < arr.length; right++) {
//         if (arr[right] !== arr[left]) {
//             uniqueCount++;
//             left = right; // move left to the new unique position
//         }
//     }

//     return uniqueCount;
// }

// // ---------- INPUT/OUTPUT HANDLER (as per typical online judge setup) ----------
// const lines = gets().trim().split(/\s+/);

// // If your platform provides input like:
// // First line: N (number of elements)
// // Second line: N space-separated sorted integers
// // You can parse like this:
// let n = parseInt(lines[0], 10);
// let arr = [];
// for (let i = 1; i <= n; i++) {
//     arr.push(parseInt(lines[i], 10));
// }

// console.log(countUniqueElements(arr));


// // 7
// // [1 1 2 2 2 3 5]

// // Output:
// // 4


// //===============================================================================
// // Input:
// // This is is a test test sentence. This this example is clear.

// // Output:
// // is test This
// function findRepeatedWords(text) {
//     // Regex to find consecutive repeated words (case-insensitive)
//     const regex = /\b(\w+)\b\s+\1\b/gi;
//     let matches = [];
//     let match;

//     // Iterate through all matches
//     while ((match = regex.exec(text)) !== null) {
//         matches.push(match[1]); // Preserve original case of first occurrence
//     }

//     // Return space-separated string
//     return matches.join(" ");
// }

// // ---------- INPUT/OUTPUT HANDLER ----------
// let text = gets(); // Reads the entire input line
// console.log(findRepeatedWords(text));

// //========================================================================

// // Input:
// // 3
// // We create unique assessments using functions only

// // Output:
// // We create 6 assessments using 9 only
// function replaceEveryKthWord(k, sentence) {
//     let words = sentence.split(" ");
//     let result = [];

//     for (let i = 0; i < words.length; i++) {
//         // Check if (i+1) is divisible by k (1-based index)
//         if ((i + 1) % k === 0) {
//             result.push(words[i].length); // Replace with length
//         } else {
//             result.push(words[i]); // Keep original word
//         }
//     }

//     return result.join(" ");
// }

// // ---------- INPUT ----------
// const k = parseInt(gets());
// const sentence = gets();

// // ---------- OUTPUT ----------
// console.log(replaceEveryKthWord(k, sentence));

// //=============================================================================
// // Input:
// // 5
// // this code is very good

// // Output:
// // siht code is yrev good
// function reverseEvenLengthWords(sentence) {
//     return sentence
//         .split(" ") // Split into words
//         .map(word => word.length % 2 === 0 ? word.split("").reverse().join("") : word) // Reverse if even length
//         .join(" "); // Join back into sentence
// }

// // ---------- INPUT ----------
// const wordsCount = parseInt(gets()); // Not used, but read as per input format
// const sentence = gets();

// // ---------- OUTPUT ----------
// console.log(reverseEvenLengthWords(sentence));

// //===========================================================================
// function reorderEvenFirst(arr) {

//     let insertPos = 0;

//     for (let i = 0; i < arr.length; i++) {

//         if (arr[i] % 2 === 0) {

//             let even = arr[i];

//             // Shift right between insertPos and i-1
//             for (let j = i; j > insertPos; j--) {
//                 arr[j] = arr[j - 1];
//             }

//             arr[insertPos] = even;
//             insertPos++;
//         }
//     }

//     return arr;
// }
// //=============================================================================
// // Input:
// // I loooove this song but ittt is nottttt for everyone

// // Output:
// // I this song but is for everyone
// function removeExaggeratedWords(text) {
//     // Split text into words
//     return text
//         .split(" ")
//         .filter(word => !/(.)\1{2,}/.test(word)) // Remove words with 3+ consecutive identical letters
//         .join(" ");
// }

// // ---------- INPUT ----------
// const text = gets(); // Reads the entire input line

// // ---------- OUTPUT ----------
// console.log(removeExaggeratedWords(text));

// //================================================================================
// // Input:
// // Moon Rises in the East Always

// // Output:
// // Moon-Rises-East-Always
// function extractCapitalizedWords(sentence) {
//     // Split sentence into words
//     const words = sentence.split(" ");
    
//     // Filter words starting with uppercase letter
//     const capitalizedWords = words.filter(word => /^[A-Z]/.test(word));
    
//     // If no capitalized words found
//     if (capitalizedWords.length === 0) {
//         return `No capitalized words found in: ${sentence}`;
//     }
    
//     // Join with hyphen
//     return capitalizedWords.join("-");
// }

// // ---------- INPUT ----------
// const sentence = gets(); // Reads the entire input line

// // ---------- OUTPUT ----------
// console.log(extractCapitalizedWords(sentence));


//==========================================================================
//palindrome


// function checkPalindromeOrMismatch(arr) {
//     let left = 0;
//     let right = arr.length - 1;
//     let sum = 0;

//     while (left < right) {
//         if (arr[left] !== arr[right]) {
//             return left; // returns index of first mismatch
//         }
//         sum += arr[left] + arr[right];
//         left++;
//         right--;
//     }

//     if (left === right) {
//         sum += arr[left]; // add middle element for odd-length arrays
//     }

//     return sum;
// }
//using functions

//=========================================================================
// 
// class Library {
//     private books: number;

//     constructor() {
//         this.books = 0; // starts at 0
//     }

//     addBook(amount: number): void {
//         if (amount > 0) {
//             this.books += amount;
//         }
//     }

//     borrowBook(amount: number): void {
//         if (amount > 0 && amount <= this.books) {
//             this.books -= amount;
//         }
//     }

//     getBooks(): number {
//         return this.books;
//     }
// }

// // ---------- INPUT HANDLING ----------
// const input: string[] = gets().split("\n");
// const operationsCount: number = parseInt(input[0]);
// let index = 1;

// const library = new Library();

// for (let i = 0; i < operationsCount; i++) {
//     const parts = input[index++].trim().split(" ");
//     const command = parts[0];

//     if (command === "add") {
//         const amount = parseInt(parts[1]);
//         library.addBook(amount);
//     } else if (command === "borrow") {
//         const amount = parseInt(parts[1]);
//         library.borrowBook(amount);
//     } else if (command === "books") {
//         console.log(library.getBooks());
//     }
// }

//========================================================================
// // Input
// // This is is a test test sentence. This this example is clear.

// // Output:
// // is test This

// function findRepeatedWords(text) {
//     let result=[]
//     let t=text.replace(/\./g, "").toLowerCase().split(" ")
//     console.log(t.length)
//     for(let i=0;i<t.length;i++){
//         if(t[i]==t[i+1]){
//             result.push(t[i])
//         }
        
//     }
//     return result
// }
//  let text = "This is is a test test sentence. This this example is clear"
//  // Reads the entire input line
//  console.log(findRepeatedWords(text));
//==========================================================================
/// // Input:
// // 3
// // We create unique assessments using functions only

// // Output:
// // We create 6 assessments using 9 only
// function replaceEveryKthWord(k,sentence){
//     const word=sentence.split(" ")
//     const result=[]
//     for(let i=0;i<word.length;i++){
//         // let w=word[i].split("")
//         // for(let j=0;j<w.length;w++){
//             if((i+1)%k==0){
//                 result.push(word[i].length)
//             }else{
//                 result.push(word[i])
//             }
        
//     }
//     return  result.join(" ")
// }

// const k = 3
// const sentence = "We create unique assessments using functions only"

// // ---------- OUTPUT ----------
// console.log(replaceEveryKthWord(k, sentence));

//===================================================================

// // Input:
// // 5
// // this code is very good

// // Output:
// // siht code is yrev good

// function reverseWithoutLoops(str){
//    const s= str.split("").reduce((acc, ch) => ch + acc, "");
//     return s
// }

// function fun(words){
//     const result=[]
//     const word= words.split(" ");
//     const wd = word.map(w =>{
//     if(w.length % 2 === 0){
//         result.push(reverseWithoutLoops(w))
//     } else{
//         result.push(w)
//     }
// });
// return result.join(" ");
// }


//  // Output: "iH John eoD"
// const st = "Hi John Doe";
// console.log(fun(st))


// const regex = //;

//     if (regex.test(timeStr)) {
//         return "Valid";
//     } else {
//         return "Invalid";


//find the length of max sub array without forbidden value
// const array=[1,2,-3,4,1,3,4,-3,5]
// let maxsum=0, start=0, forbidden=3
// for(let i=0;i<array.length;i++){
//     //sum+=i;
//      if(array[i]==forbidden){
//           start=start+i+1;
//      }7
//      maxsum=Math.max(maxsum,i-start+1)

// } 
// console.log(maxsum)

//=================================================================================
// [2.]
// const paragraph = "The cat bat sat on the big red bat" 
// const s=paragraph.split(" ")
// const regex = /\b[^aeiou\s?][aeiou\s?][^aeiou\s?]\b/ig;
// let count=0
// for(let i=0;i<s.length;i++){
//     if(s[i].match(regex)){
//     count++
// }
// }

// // const count = matches ? matches.length : 0;
// console.log(count); // Output: 5
//=====================================

// let words = [ "apple", "banana", "kiwi", "grape", "orange" ]


// for(let i = 0; i < words.length; i++) // no of passes
// {
//     for(let j = 0; j < words.length - 1; j++) // comparing 2 elements
//     {
//         let curentWordChar = words[j].substring(words[j].length - 1)
//         let nextWordChar = words[j + 1].substring(words[j + 1].length - 1) 

//         if(curentWordChar > nextWordChar) //e > a
//         {
//            [ words[j + 1], words[j] ]  = [ words[j], words[j + 1]  ]
//         }
//     }
// }// let output = [ "banana", "apple", "grape", "orange", "kiwi" ]

// console.log(words)


// let words = [ "apple", "banana", "kiwi", "grape", "orange" ];

// for (let i = 0; i < words.length; i++) { // number of passes
//   for (let j = 0; j < words.length - 1 - i; j++) { // compare adjacent pairs
//     const currentWordChar = words[j].at(-1);
//     const nextWordChar = words[j + 1].at(-1);

//     if (currentWordChar > nextWordChar) {
//       [words[j], words[j + 1]] = [words[j + 1], words[j]];
//     }
//   }
// }

// console.log(words); // [ "banana", "apple", "grape", "orange", "kiwi" ]
// //=============================================================================
// const data = ["flower", "flow", "flight"]

// let prefix = data[0]
// // prefix = "flower"

// for(let i = 1; i < data.length; i++)
// {
//     let next = data[i]
//     // next = "flight"
//     // prefix = "flow"
//     while(!next.startsWith(prefix))
//     {
//        prefix = prefix.substring(0, prefix.length - 1)
//     //    prefix = "fl"
//     }
// }

// console.log(prefix)



function extractVowelGroups(sentence) {
    const matches = sentence.match(/[aeiou]/gi);
    return matches ? matches.join(" ") : "";
}

const s = "i love university";
console.log(extractVowelGroups(s));
// Output: [ 'i', 'o', 'e', 'u', 'i', 'e', 'i' ]
