export class StaticPage {
    constructor(page) {
        this.page = page;
        this.dragArea = '#dragarea';
        this.dropArea = '#droparea';
    }
    async navigate() {
        await this.page.goto('https://demo.automationtesting.in/Static.html');
    }
    async dragAndDrop(elementId) {
        const source = this.page.locator(`#${elementId}`);
        const target = this.page.locator(this.dropArea);
        await source.dragTo(target);
    }
    async getDroppedElementsCount() {
        return await this.page.locator(`${this.dropArea} > img`).count();
    }
}
