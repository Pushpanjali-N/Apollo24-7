import { expect } from '@playwright/test';
export class findSpecialist{
    
    constructor(page){
        this.page=page
        this.iconButton=this.page.locator('.icon-down-arrow')
        this.oneSpecificSpeciality=this.page.locator('//div[contains(@class,"QuickBook_specialitySearchInputField")]//following::ul[1]//li//span').nth(2)
        this.locationInput = this.page.locator('input[placeholder*="location"]')
        this.bangaloreOption = this.page.locator('text=Bangalore, Karnataka').first()
        this.parentOptions = this.page.locator("div[class^='QuickBook_autoSearchPopover__']")
        this.dateInput=this.page.locator('span[class*="QuickBook_datepickerField"]').first();
        this.clickOnDate=(ariaLabel) =>this.page.locator(`button.react-calendar__tile:has(abbr[aria-label="${ariaLabel}"])`).first()
        this.button=this.page.getByRole('button', { name: 'Button' })
        this.emptyMessage=this.page.getByText(/No doctors found for selected filters, please try for another date/i)
        this.viewDoctors=this.page.locator('label:has-text("Best matching doctors for your search")')
    }
    
    async selectSpeciality(){
        await this.iconButton.click()
        await this.oneSpecificSpeciality.click()
    }
    async selectFutureDate() {
        await this.dateInput.click();
        const d = new Date();
        d.setDate(d.getDate() + 1);
        const ariaLabel = d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
        await this.clickOnDate(ariaLabel).click();
    }

    async selectCity() {
        await this.locationInput.click()
        for (const char of 'Bangalore, Karnataka') {
          await this.page.keyboard.press(char);
        }
        await this.bangaloreOption.waitFor({ state: 'visible' });
        await this.bangaloreOption.click()
        await expect(this.locationInput).toHaveValue(/Bangalore/i);
       
        
    }

    async oneTimeSubmit(){
        await this.button.click();
        //assertion
        await expect(this.page).toHaveURL(/quick-book-listing/);
        
        await expect(
            (this.emptyMessage)
            .or(this.viewDoctors)
        ).toBeVisible({ timeout: 10000 });

    }
    
}


