
import { expect } from '@playwright/test';

export class multipleFilter {
  constructor(page) {
    this.page = page;
    this.feeFilter=this.page.locator('div:nth-child(7) > label > .CustomCheckbox_checkMark__Jp3bK').first()
    this.feeEls = this.page.locator('p[class*="DoctorCard_fee"]'); 
  }

  async feeRangeFilter() {
    await Promise.all([
    this.feeFilter.click(),
    this.page.waitForLoadState('networkidle') // waits until there are no network connections for a short time
    ]);


    await expect(this.feeEls.first()).toBeVisible();
    const allFees = await this.feeEls.allTextContents();

    for (const feeText of allFees) {
      const match = feeText.match(/(\d+)/);
      expect(match).not.toBeNull();
      const fee = Number(match[1]);
      expect(fee).toBeGreaterThanOrEqual(100);
      expect(fee).toBeLessThanOrEqual(500);
    }
  }
}
