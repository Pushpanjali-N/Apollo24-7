import { expect } from '@playwright/test';
export class find{
    
    constructor(page){
        this.page=page
        this.specialist=this.page.locator('p.Kd').nth(1)
        // this.uncheckOnlineCunsult=this.page.locator('input[type="checkbox"][name="ONLINE"]')
        this.uncheckOnlineCunsult=this.page.locator('label:nth-child(2) > .CustomCheckbox_checkMark__Jp3bK').first()
        // this.expFilter=this.page.getByRole('checkbox',{name:/0-5/})
        this.expFilter=this.page.locator('div:nth-child(5) > label > .CustomCheckbox_checkMark__Jp3bK').first()
        this.expEls=this.page.locator('p[class*="DoctorCard_experience"]')
    
    }
    async  Specialties(){
        await this.specialist.click()
    }
    async uncheckOnlineCunsultbtn(){
        await this.uncheckOnlineCunsult.uncheck() 
          
        
    }
    async experianceFilter() {
        await this.expFilter.first().click()
        await this.page.waitForTimeout(5000)
        await expect(this.expEls.first()).toBeVisible()
        const allTexts = await this.expEls.allTextContents()
        for (const text of allTexts) {
            const match = text.match(/(\d+)/);// matches any digit
            expect(match).not.toBeNull();
            const years = Number(match[1]);// converting string to numeric
            expect(years).toBeGreaterThanOrEqual(0);
            expect(years).toBeLessThanOrEqual(5);
        }
    }
   
    
}

