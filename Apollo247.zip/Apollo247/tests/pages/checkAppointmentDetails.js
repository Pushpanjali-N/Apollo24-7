import { expect } from '@playwright/test';
export class checkMyAppointment{
    
    constructor(page){
        this.page=page
        this.myAccount=this.page.locator('div[title="Login/SignUp"]')
        this.myAppointmemt=this.page.getByRole('link',{hasText:'My Appointments'}).nth(2)
        this.title=this.page.getByRole('heading', { name: /My Appointments/i })
        this.list=this.page.locator('div[class*="ListStyles_appointmentList__"]')
        this.cards=this.list.locator('a[href^="/chat-room/"]')
        
    }
    async clickOnMyAccount(){
        await this.myAccount.click()
    }
    async clickOnMyAppointment(){
        await this.myAppointmemt.click()
    }

    async printDetails(){
        await expect(this.title).toBeVisible()
        await expect(this.list.first()).toBeVisible()
        await expect(this.cards.first()).toBeVisible()
        const count = await this.cards.count();
        console.log(`My Appointments: ${count}`)
        expect(count).toBeGreaterThan(0)

        for (let i = 0; i < count; i++) {
            const cardText = await this.cards.nth(i).innerText();
            console.log(`\nAppointment ${i + 1}:`);
            console.log(cardText);
        }

    }

}