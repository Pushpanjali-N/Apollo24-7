import { expect } from '@playwright/test';
import { loginDetails } from './loginDetails';
export class appointmentBooking{  
  constructor(page){
    this.page=page
    this.physician=this.page.locator('[class*="List_doctorList"] a[href^="/doctors/"]').nth(3)
    this.viewProfile=this.page.locator('button', { hasText: /^View Profile$/ }).first()
    this.dateSelection= this.page.locator('.slots_dateWrapper__gqy5a').nth(3);
    this.timeSlotSelection=this.page.locator('.slots_slots__W0wMX').nth(0)
    this.scheduleAppointment=this.page.getByRole('button', { name: 'Button' }).nth(3)
    this.confirmBtn=this.page.locator('button').filter({ hasText: 'Confirm Appointment' })
    this.assertMain=this.page.getByRole('main')
  }
  async gernalPhysician(){
    await this.physician.click()
    await expect(this.page.locator('h1, [data-testid="doctor-name"]')).toBeVisible()
  }

  async viewProfileBtn(){
    if (!this.page.url().includes('/doctors/')) {
      await this.viewProfile.click().catch(() => {})
    }
  }
  async selectTomorrow() {
    await this.dateSelection.click()   
  }
  async timeSlot() {
    await this.timeSlotSelection.click()
  }
  async scheduleAppointmentBtn(){
    await this.scheduleAppointment.click()
  }
  async confirmButton(){
    await this.confirmBtn.click()
    await expect(this.assertMain).toMatchAriaSnapshot(`
    - img
    - heading "Appointment Confirmed" [level=5]
    - paragraph
    `);

  }
  
}


 

    

 

