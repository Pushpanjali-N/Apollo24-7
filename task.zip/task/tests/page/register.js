export class RegisterPage {
    constructor(page) {
        this.page = page;
        this.firstName = page.locator('input[placeholder="First Name"]');
        this.lastName = page.locator('input[placeholder="Last Name"]');
        this.address = page.locator('textarea[ng-model="Adress"]');
        this.email = page.locator('input[type="email"]');
        this.phone = page.locator('input[type="tel"]');
        this.genderMale = page.locator('input[value="Male"]');
        // this.Languages=page.locator('.ng-scope')
        this.hobbyCricket = page.locator('#checkbox1');
        this.hobbyMovies = page.locator('#checkbox2');
        this.skills = page.locator('#Skills');
        this.select2 = page.locator('.select2-selection');
        this.year = page.locator('#yearbox');
        this.month = page.locator('select[ng-model="monthbox"]');
        this.day = page.locator('#daybox');
        this.password = page.locator('#firstpassword');
        this.confirmPassword = page.locator('#secondpassword');
        this.fileUpload = page.locator('#imagesrc');
        this.refresh = page.locator('#Button1');
    }
    async open() {
        await this.page.goto('https://demo.automationtesting.in/Register.html');

    }

    async fillName(first, last) {
        await this.firstName.fill(first);
        await this.lastName.fill(last);
    }
    async fillAddress(addr) {
        await this.address.fill(addr);
    }
    async fillContact(email, phone) {
        await this.email.fill(email);
        await this.phone.fill(phone);
    }
    async selectGender() {
        await this.genderMale.check();

    }
   
    async selectHobbies() {
        await this.hobbyCricket.check();
        await this.hobbyMovies.check();
    }
     async selectLanguages(){
        
await this.page.locator('#msdd').click();
// await this.page.locator('//ul[contains(@class,"ui-autocomplete")]//li[contains(@class,"list-select") and normalize-space()="Croatian"]').click();
await this.page.locator('li.list-select.ng-scope', { hasText: 'Croatian' }).first().click();
        // await this.Languages.nth(1).click()
    }

    async selectSkills(value) {
        await this.page.waitForSelector('#Skills option:nth-child(2)');
        await this.skills.selectOption(value);
    }



    async selectCountry(name) {
        await this.select2.click();
        await this.page.getByText(name, { exact: true }).nth(1).click();
    }


    async selectDOB(y, m, d) {
        await this.year.selectOption(y);
        await this.month.selectOption(m);
        await this.day.selectOption(d);
    }


    async setPassword(pwd) {
        await this.password.fill(pwd);
        await this.confirmPassword.fill(pwd);
    }
    async uploadFile(path) {
        await this.fileUpload.setInputFiles("C:\\Users\\pushpn\\Desktop\\invalidInputData.xlsx");
    }
    async refreshPage() {
        await this.refresh.click();
    }

}

    