import { data as test} from '../utils/NavigationFixture.js';
import { readData } from '../utils/excelReader.js'
import { find } from '../pages/appliedFilters.js';
import { appointmentBooking } from '../pages/scheduleAppointment.js';
import { findSpecialist } from '../pages/doctorSearch.js';
import { loginDetails } from '../pages/loginDetails.js';
import {checkMyAppointment} from '../pages/checkAppointmentDetails.js'
import { multipleFilter } from '../pages/multipleFilter.js';
import { invalidInputSearch } from '../pages/invalidInput.js';
import {mobileNumber} from '../data/loginData.json'

test.setTimeout(120_000)
test.describe("group",  function(){
  test.beforeEach( async function( {logindata }){
    await logindata.gotoHome()
    await logindata.openFindDoctors()
   
  })

  async function applyFilters(page) {
    const filters = new find(page);
    await filters.Specialties();
    await filters.uncheckOnlineCunsultbtn()
    await filters.experianceFilter();
   
  }
  /**
   * =========================================================================================================
   * Testcase: 1
   * Description -- verify results match selected filters
   * Created By -- Pushpanjali N
   * Reviewed By -- Gujjula Narasimha Reddy
   * Positive Test case : validate
   * =========================================================================================================
   * Steps:
   * - Open browser
   * - Navigate to Apollo 24/7 website
   * - Click on “Find Doctors”
   * - Select any specialty from the list
   * - Choose either “Consult Online” or “Hospital Visit” option
   * - Click on “Search” to view doctors
   * =========================================================================================================
  **/


  test.only('verify results match selected filters', async ({ page }) => {
    await  applyFilters(page)
    
  })
  /**
   * =========================================================================================================
   * Testcase: 2
   * Description -- Verify specialist booking flow with future date and city selection
   * Created By -- Pushpanjali N
   * Reviewed By -- Gujjula Narasimha Reddy
   * Positive Test case : validate
   * =========================================================================================================
   * Steps:
   * - Open browser
   * - Navigate to Apollo 24/7 website
   * - Click on “Find Doctors”
   * - Select any specialty from the list
   * - Choose either “Consult Online” or “Hospital Visit” option
   * - Click on “Search” to view doctors
   * =========================================================================================================
  **/

  test.only('Verify specialist booking flow with future date and city selection ', async ({page})=>{
    
    let pageObj=new findSpecialist(page)
    await pageObj.selectSpeciality()
    await pageObj.selectFutureDate();
    await pageObj.selectCity(); 
    await pageObj.oneTimeSubmit()

  })
  /**
   * =========================================================================================================
   * Testcase: 3
   * Description -- Apply multiple filters and verify fee range on Find Doctors page
   * Created By -- Pushpanjali N
   * Reviewed By -- Gujjula Narasimha Reddy
   * Positive Test case : validate
   * =========================================================================================================
   * Steps:
   * - Open browser
   * - Navigate to Apollo 24/7 website
   * - Click on “Find Doctors”
   * - Select any specialty from the list
   * - Choose either “Consult Online” or “Hospital Visit” option
   * - Click on “Search” to view doctors
   * =========================================================================================================
  **/
  test.only('Apply multiple filters and verify fee range on Find Doctors page', async ({page})=>{
    let filterFee=new multipleFilter(page)
    await applyFilters(page)
    await filterFee.feeRangeFilter()
  })
  /**
   * =========================================================================================================
   * Testcase: 4
   * Description -- Validate search results for invalid input
   * Created By -- Pushpanjali N
   * Reviewed By -- Gujjula Narasimha Reddy
   * NNegative Test case : validate
   * =========================================================================================================
   * Steps:
   * - Open browser
   * - Navigate to Apollo 24/7 website
   * - Click on “Find Doctors”
   * - Select any specialty from the list
   * - Choose either “Consult Online” or “Hospital Visit” option
   * - Click on “Search” to view doctors
   * =========================================================================================================
  **/

  test.only('Validate search results for invalid input', async function({page}){
    let invalidDataInp=new invalidInputSearch(page)
    const result = readData("invalidInputData.xlsx","invalidData")
    for(let i of result){
      await invalidDataInp.searchForInvalidInput(i.invalidInputData);
    }
    
  })
  /**
   * =========================================================================================================
   * Testcase: 5
   * Description -- Verify that an appointment is scheduled successfully
   * Created By -- Pushpanjali N
   * Reviewed By -- Gujjula Narasimha Reddy
   * Positive Test case : validate
   * =========================================================================================================
   * Steps:
   * - Open browser
   * - Navigate to Apollo 24/7 website
   * - Click on “Find Doctors”
   * - Select any specialty from the list
   * - Choose either “Consult Online” or “Hospital Visit” option
   * - Click on “Search” to view doctors
   * =========================================================================================================
  **/
  test("Verify that an appointment is scheduled successfully", async ({page,logindata})=>{
    let appointment=new appointmentBooking(page)

    await applyFilters(page)
    await appointment.gernalPhysician()
    await appointment.viewProfileBtn()
    await appointment.selectTomorrow()
    await appointment.timeSlot() 
    await appointment.scheduleAppointmentBtn()
    await logindata.Login() 
    await appointment.confirmButton()
    
  }) 
})
/**
   * =========================================================================================================
   * Testcase: 6
   * Description -- Check that booked appointment details (date & time) are visible
   * Created By -- Pushpanjali N
   * Reviewed By -- Gujjula Narasimha Reddy
   * Positive Test case : validate
   * =========================================================================================================
   * Steps:
   * - Open browser
   * - Navigate to Apollo 24/7 website
   * - Click on “Find Doctors”
   * - Select any specialty from the list
   * - Choose either “Consult Online” or “Hospital Visit” option
   * - Click on “Search” to view doctors
   * =========================================================================================================
  **/

test('Check that booked appointment details (date & time) are visible', async ({page, logindata })=>{
  await logindata.gotoHome()
  const login = new loginDetails(page);
  const appt  = new checkMyAppointment(page);
  await login.clickLogin();
  await logindata.Login()
  await appt.clickOnMyAccount();
  await appt.clickOnMyAppointment();
  await appt.printDetails()
});


