
// framesPage.js
import { expect } from '@playwright/test';

export class FramesPage {
  constructor(page) {
    this.page = page;
    this.singleFrame=this.page.frameLocator('#singleframe')
    this.input=this.singleFrame.locator('input[type="text"]')
    this.iframe=this.page.getByText('Iframe with in an Iframe')
    this.outerFrame = this.page.frameLocator('iframe[src="MultipleFrames.html"]')
    this.innerFrame=this.outerFrame.frameLocator('iframe')
    this.fillInnerFrame=this.innerFrame.locator('input[type="text"]')
  }
  async navigate() {
    await this.page.goto('https://demo.automationtesting.in/Frames.html');

    }

  async enterTextInSingleFrame(text) {
    
    await this.input.fill(text);
    await expect(this.input).toHaveValue(text);
  }

  async enterTextInNestedFrame(text) {
    // Click the tab/section for nested iframes
    await this.iframe.click();
    await this.fillInnerFrame.fill(text);
    await expect(this.fillInnerFrame).toHaveValue(text);
  }
}
