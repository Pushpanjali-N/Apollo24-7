import{test,expect} from '@playwright/test'
import {RegisterPage  } from '../page/register'
import { AlertsPage } from '../page/alerts'
import { FramesPage} from '../page/frames.js'
import {StaticPage} from '../page/static.js'
import {WindowsPage} from '../page/windows.js'
import { BrowserUtils } from '../utils/browserUtils.js'

const browserName=["chromium","firefox"]
for(let i of browserName){
  let page;
  const utilCall=new BrowserUtils();
  test.describe(`positive Testcases on ${i}`,()=>{
    test.beforeAll(async()=>{
      page=await utilCall.launchBrowser(i)
    })
    test.afterAll(async ()=>{
      await utilCall.closeBrowser()
    })
  test('Register page POM', async () => {
    const register = new RegisterPage(page);
    await register.open()
    await register.fillName('pushpanjali', 'n');
    await register.fillAddress('talawade, Pune, Maharashtra');
    await register.fillContact('capgemini@gmail.com', '432543254');
    await register.selectGender();
   
    await register.selectHobbies();
    //  await register.selectLanguages()
    // await register.selectSkills('AutoCAD');
    await register.selectCountry('Bangladesh');
    await register.selectDOB('1928', 'July', '16');
    await register.setPassword('Welcome1');
    await register.uploadFile('invalidInputData.xlsx');
    await register.refreshPage();
    // Optional sanity assertion
    await expect(page).toHaveURL(/Register/i);
  });

    test('Alerts handling using POM', async () => {
        const alertsPage = new AlertsPage(page);
        await alertsPage.navigate()
        await alertsPage.handleSimpleAlert();
        await alertsPage.handleConfirmAlertAccept();
        await alertsPage.handleConfirmAlertDismiss();
        await alertsPage.handlePromptAlert();
    });

    test('Frames handling using POM', async () => {
        const framesPage = new FramesPage(page);
        await framesPage.navigate()
        await framesPage.enterTextInSingleFrame('Automation');
        await framesPage.enterTextInNestedFrame('Playwright');

    });

    test('Open New Tabbed Window using POM', async () => {
        const windowsPage = new WindowsPage(page);
        await windowsPage.navigate()
        await windowsPage.openNewTabbedWindow();
    });


    test('Static Drag and Drop - POM', async () => {
        const staticPage = new StaticPage(page);
        await staticPage.navigate()
        await staticPage.dragAndDrop('angular');
        await staticPage.dragAndDrop('mongo');
        await staticPage.dragAndDrop('node');
        await page.waitForTimeout(1000)
        const count = await staticPage.getDroppedElementsCount();

        expect(count).toBe(3);
    });
})
}



