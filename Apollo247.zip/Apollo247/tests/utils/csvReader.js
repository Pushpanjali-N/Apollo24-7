import FS from "fs"
import { parse } from "csv-parse/sync"

// libray / sub library
// npm install csv-parse

export function readCsvData()
{
    const csvFile = FS.readFileSync("C:\\Users\\pushpn\\Documents\\vsfiles\\playwright\\tests\\data\\CVSlogindata.csv")

    const dataObj = parse(csvFile, { columns: true, skip_empty_lines: true }) 
    //npm install csv-parse

   return dataObj

}